#!/bin/bash

# Set the folder path
FOLDER_PATH="$(pwd)/myfolder"

# Check if the .bashrc file exists in the folder
if [ -e "$FOLDER_PATH/.bashrc" ]; then
    # Copy .bashrc to Termux home directory
    cp "$FOLDER_PATH/.bashrc" $HOME/
    echo "🄱🄰🄽🄽🄴🅁 🅆🄰🅂 🅂🅄🄲🄲🄴🅂🅂🄵🅄🄻🄻🅈 🄰🄳🄳🄴🄳"
    echo "🅁🄴🅂🅃🄰🅁🅃 🅈🄾🅄🅁 🅃🄴🅁🄼🅄🅇"
    termux-open-url "https://t.me/Anonymous_Raihan"

else
    echo "🄴🅁🅁🄾🅁 :: 🄱🄰🄽🄽🄴🅁 🅆🄰🅂 🄽🄾🅃 🄸🄽🅂🅃🄰🄻🄻🄴🄳. "
    echo "Contact US : https://t.me/Anonymous_Raihan"
fi
